from . import binproxy
def lambda_handler(event, context):
    try:
        toolName = ""
        toolName = event["name"]
        if not toolName:
            return "could not process request."
        url = binproxy.get_tool_url(toolName)
        bin_data = binproxy.fetch_tool(url)
        return bin_data
    except Exception as e:
        print(e)
    